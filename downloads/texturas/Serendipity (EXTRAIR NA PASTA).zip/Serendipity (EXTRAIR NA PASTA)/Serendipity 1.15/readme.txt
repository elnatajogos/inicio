~~~~~ Realistic Default ~~~~~

DISCLAIMER:
I tried to remove any work from others. However, this pack started as a personal project so there is possibly unoriginal work. If you see anything, let me know and I will make changes.

~~~~~

CREDIT:

JoyJoy_ - Custom font tool
https://www.reddit.com/r/Minecraft/comments/2xx1ym/are_you_tired_of_the_default_minecraft_font/

Blockbench - Custom 3d modeling program

MrCrayFish's 3d modeling program

GIMP

~~~~~

INSPIRATION/REFERENCE:

A few mobs - Wayuki
Some ctm files - John Smith
Inspired me to start the pack - SMP Revival & Pamplemousse